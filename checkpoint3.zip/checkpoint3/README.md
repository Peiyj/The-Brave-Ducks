# Checkpoint 3 Links
The Brave Ducks

## Link to our notebooks:

Notebook for Use Of Force: https://observablehq.com/d/30ad277cb0542590

Notebook for Illegal Search: https://observablehq.com/d/ac4a094f9b93f569

